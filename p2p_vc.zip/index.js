import firebase from 'firebase/app';
import 'firebase/firestore';

const firebaseConfig = {
  apiKey: "AIzaSyBhJcL5za6Pz01R1ItUmz2dkyx4ACvg_P8",
  authDomain: "randomeet-16bf4.firebaseapp.com",
  projectId: "randomeet-16bf4",
  storageBucket: "randomeet-16bf4.appspot.com",
  messagingSenderId: "177548240355",
  appId: "1:177548240355:web:feb0b35317fd9e61536cd6",
  measurementId: "G-CFMG1Y1HDH"
};

if (!firebase.apps.length){ 
  //firebase.apps.length property indicates the number of Firebase apps that have been initialized
  // to ensure the app is initialized only once
  firebase.initializeApp(firebaseConfig)
}

const firestore = firebase.firestore();

const servers = {
    iceServers: [
      {
        urls: ['stun:stun1.l.google.com:19302', 'stun:stun2.l.google.com:19302'],
      },
    ],
    iceCandidatePoolSize: 10,
  };

const pc = new RTCPeerConnection(servers);

var localStream = null;
var remoteStream = null;

const webCamButton = document.getElementById("webCam");
const localVideo = document.getElementById("localVideo");
const remoteVideo = document.getElementById("remoteVideo");
const callButton = document.getElementById("callButton");
const shareScreen = document.getElementById("shareScreen")
const endCall = document.getElementById("endCall")
const sendFile = document.getElementById("sendFile")
const shareGithubId = document.getElementById("shareGithubId")
const answerButton = document.getElementById("answerButton")
const callInput = document.getElementById("callInput")


webCamButton.onclick = async () => {
    localStream = await navigator.mediaDevices.getUserMedia( { video : true, audio : true } );
    remoteStream = new MediaStream();

    //Sending stream
    localStream.getTracks().forEach((track) => {
        pc.addTrack(track, localStream)
    })

    //setting remote stream
    pc.ontrack = (event) => {
        event.streams[0].getTracks().forEach((track) => {
            remoteStream.addTrack(track)
        })
    }

    localVideo.srcObject = localStream
    remoteVideo.srcObject = remoteStream

    callButton.disabled = false;
    answerButton.disabled = false;
    webCamButton.disabled = true;
}

// creating offer
callButton.onclick = async () => {
  const calldoc = firestore.collection("calls").doc();
  const offerCandidates = calldoc.collection('offerCandidates')
  const answerCandidates = calldoc.collection('answerCandidates')

  callInput.value = calldoc.id;

  pc.onicecandidate = (event) => {
    event.candidate && offerCandidates.add(event.candidate.toJSON());
  }

  const offerDescription = await pc.createOffer();
  await pc.setLocalDescription(offerDescription)

  const offer = {
    sdp : offerDescription.sdp,
    type : offerDescription.type
  }

  await calldoc.set( { offer } )

  calldoc.onSnapshot((snapshot) => {
    const data = snapshot.data();
    if (!pc.currentRemoteDescription && data?.answer){
      const answerDiscription = new RTCPeerConnection(data.answer);
      pc.setRemoteDescription(answerDiscription)
    }
  })


  answerCandidates.onSnapshot((snapshot) => {
    snapshot.docChanges().forEach((change) => {
      if (change.type === "added"){
        const candidate = new RTCPeerConnection(change.doc.data())
        pc.onicecandidate(candidate);
      }
    })
  })
  
  endCall.disabled = false;

}

answerButton.onclick = async () => {
  const callId = callInput.value
  const callDoc = firestore.collection("calls").doc(callId);
  const offerCandidates = callDoc.collection("offercandidates")
  const answerCandidates = callDoc.collection("answerCandidates")

  pc.onicecandidate = (event) => {
    event.candidate && answerCandidates.add(event.candidate.toJSON())
  }

  const callData = (await callDoc.get()).data()

  const offerDescription = callData.offer;
  await pc.setRemoteDescription(offerDescription)

  const answerDiscription = await pc.createAnswer();
  await pc.setLocalDescription(answerDiscription);

  const answer = {
    sdp : answerDiscription.sdp,
    type : answerDiscription.type
  }

  await callDoc.update( { answer } )

  offerCandidates.onSnapshot((snapshot) => {
    snapshot.docChanges().forEach((change) => {
      console.log(change)
      if (change.type === "added"){
        let data = change.doc.data();
        pc.addIceCandidate(new RTCPeerConnection(data))
      }
    }) 
  })

}

