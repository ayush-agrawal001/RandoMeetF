import React from "react";
import Navbar from "../components/Navbar";

function Room(){
    return(
        <div id="roomContainer">
            <h1>{`Welcome to <RandoMeet>`}</h1>
            <div id="videoContainer">
                <video id="localVideo"  autoPlay playsInline></video>
                <video id="remoteVideo"  autoPlay playsInline></video>
            </div>
            <h2>{`Finding Your <RandoPeer>...`}</h2>
            <input id="callInput"/> <button id="answerButton" disabled>Answer</button>
            <Navbar />
        </div>
    )
}
export default Room;