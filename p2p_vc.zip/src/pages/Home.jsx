import React from "react";
import { passUse } from "../contexts/authContext";

const Home = ()  => {
    const { num } = passUse()

    return(
    <div className ="home_container">
    {/* <form action="http://localhost:3000/auth/github" method="get"> */}
    <form action="/room" method="get">
        <button type="submit" className="login-with-google-btn">
            Sign in with Github
        </button>
    </form>
    </div>
    )
}

export default Home;