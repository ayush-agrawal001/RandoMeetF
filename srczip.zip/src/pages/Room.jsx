import React from "react";

function Room(){
    return(
        <h1>Room</h1>
    )
}
export default Room;