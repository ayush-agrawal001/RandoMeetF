import React, { useEffect, useState } from "react";
import { Routes, Route } from "react-router-dom"
import Home from "./pages/Home";

import { PassportProvider } from "./contexts/authContext"
import axios, { Axios } from "axios";

const App = () => {
  
  const [isAuth, setIsAuth] = useState(null) 
  const [exesToken, setExesToken] = useState(null) 

  useEffect(() => {
    async function getData(){const response = await axios.get("http://localhost:3000/login/success")
    const result = response.data
    console.log(result);
    setIsAuth(result.success)
    }
    getData();
  }, [])

  return(
    <div>
    <PassportProvider>
    <Routes>
      <Route path="/" element={<Home />}></Route>
      <Route path="/room" element={isAuth ? <h1>Room</h1> : <h1>isAuth false</h1>}></Route>
    </Routes>
    </PassportProvider>
    </div>
  )
}

export default App;