import React from "react";
import { createContext } from "react";
import { useContext } from "react";

export const passUse = () => {
    return useContext(PassportContext)
}

const PassportContext = React.createContext();

export const PassportProvider = (props) => {
    return(
        <PassportContext.Provider value={ {  } }>
            {props.children}
        </PassportContext.Provider>
    )
} 