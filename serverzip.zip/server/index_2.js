import express from 'express';
import bodyParser from 'body-parser';
import pg from 'pg';
import session from 'express-session';
import passport from 'passport';
import { Strategy as GitHubStrategy } from 'passport-github';
import dotenv from 'dotenv';
import cors from 'cors';

dotenv.config();

const app = express();
const port = 3000;
const clientUrl = "http://localhost:5173";

app.use(
  session({
    secret: process.env.SESSION_SECRET,
    resave: false,
    saveUninitialized: true,
  })
);

app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static('public'));

app.use(cors({
  origin: clientUrl,
  methods: "GET,POST,PUT,DELETE",
  credentials: true,
}));

app.use(passport.initialize());
app.use(passport.session());

const db = new pg.Client({
  user: process.env.PG_USER,
  host: process.env.PG_HOST,
  database: process.env.PG_DATABASE,
  password: process.env.PG_PASSWORD,
  port: process.env.PG_PORT,
});

db.connect();

app.get('/auth/status', (req, res) => {
  if (req.isAuthenticated()) {
    res.json({ auth: true, user: req.user });
  } else {
    res.json({ auth: false });
  }
});

// When User clicks, redirected here
app.get('/auth/github', passport.authenticate('github', { scope: ['user:email'] }));

// After login or sign-in, the user is redirected
app.get('/auth/github/callback',
  passport.authenticate('github', {
    successRedirect: clientUrl + '/room',
    failureRedirect: clientUrl + '/home',
  })
);

// Doing the OAuth process, also handles the GitHub part
passport.use('github', new GitHubStrategy({
  clientID: process.env.GITHUB_CLIENT_ID,
  clientSecret: process.env.GITHUB_CLIENT_SECRET,
  callbackURL: 'http://localhost:3000/auth/github/callback',
}, async (accessToken, refreshToken, profile, cb) => {
  try {
    const result = await db.query(
      'SELECT * FROM users WHERE username = $1', [profile.id]
    );
    if (result.rows.length === 0) {
      const newUser = await db.query(
        'INSERT INTO users (username) VALUES ($1) RETURNING *', [profile.id]
      );
      return cb(null, newUser.rows[0]);
    } else {
      return cb(null, result.rows[0]);
    }
  } catch (err) {
    return cb(err);
  }
}));

passport.serializeUser((user, cb) => {
  console.log('Serializing user:', user);
  cb(null, user);
});

passport.deserializeUser((user, cb) => {
  console.log('Deserializing user:', user);
  cb(null, user);
});

app.listen(port, () => {
  console.log(`Server running on port ${port}`);
});
