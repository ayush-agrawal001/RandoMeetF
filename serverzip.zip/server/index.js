import express from "express";
import bodyParser from "body-parser";
import pg from "pg";
import passport from "passport";
// import GoogleStrategy from "passport-google-oauth2";
import session from "express-session";
import { Strategy as GitHubStrategy } from 'passport-github';
import env from "dotenv";
import cors from "cors";


const app = express();
const port = 3000;
const clientUrl = "http://localhost:5173"
env.config();


//Allowing Frontend to use my backend
app.use(cors({
  origin : clientUrl,
  method : "GET,POST,PUT,DELETE",
  credentials : true,
}))  

app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static("public"));

app.use(
  session({
    secret: process.env.SESSION_SECRET,
    cookie: { 
      secure: false
    },
    resave: false,
    saveUninitialized: true,
  })
);

app.use(passport.initialize());
app.use(passport.session());

const db = new pg.Client({
  user: process.env.PG_USER,
  host: process.env.PG_HOST,
  database: process.env.PG_DATABASE,
  password: process.env.PG_PASSWORD,
  port: process.env.PG_PORT,
});

db.connect();

app.get("/login/success", (req,res) => {
  if(req.user) {
  res.status(200).json({
     success:true,
     message: "successful",
     user: req.user,
     //cookies: req.cookies
 });
}else{
  res.json({
    success:false,
    message: "notSuccessful",
    // user: req.user,
    //cookies: req.cookies
}); 
}
});


// When User click, redirected here 
app.get(
  "/auth/github",
  passport.authenticate("github", {
    scope: ["profile"],
  })
);

//After login or signin the user is redirected or do not redirected
app.get(
  "/auth/github/callback",
  passport.authenticate("github", {
    successRedirect: clientUrl + "/room" ,
    failureRedirect: clientUrl + "/home",
  })
);

//Doing the oAuth process, also handles the github part  
passport.use( "github",
  new GitHubStrategy({
    clientID: process.env.GITHUB_CLIENT_ID,
    clientSecret: process.env.GITHUB_CLIENT_SECRET,
    callbackURL: "http://localhost:3000/auth/github/callback"
  },
  async function (accessToken, refreshToken, profile, cb) {
    // { githubId: profile.id }
    try {
      const result = await db.query(
        "SELECT * FROM users WHERE username = $1", [profile.id]
      )
      if (result.rows.length === 0){
        const newUser = await db.query("INSERT INTO users (username) VALUES ($1) RETURNING *", [profile.id])
        return cb(null, newUser.rows[0]);
      }else{
        return cb(null, result.rows[0]);
      }
    }catch (err){
      return cb(err)
    } 
  }
));

passport.serializeUser((user, cb) => {
  console.log("Serializing user:", user);
  cb(null, user);
}); // for storing cookie in users browser

passport.deserializeUser((user, cb) => {
  console.log("Deserializing user:", user);
  cb(null, user);
});// for using the cookie in users browser


app.listen(port, () => {
  console.log(`Server running on port ${port}`);
});
